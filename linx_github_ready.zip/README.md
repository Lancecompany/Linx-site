# Linx Web Project

Este repositorio contiene una maqueta de un sitio web con las siguientes secciones:
- Página principal (`index.html`)
- Productos (`productos.html`)
- Detalles del producto (`detalles-producto.html`)
- Contacto y soporte (`contacto-soporte.html`)
- Artículos y detalles (`articulos-detalles.html`)
- Blog y reseñas (`blog-reseñas.html`)

## Estructura
- Los archivos HTML están en la raíz.
- Los recursos (imágenes) están dentro de la carpeta `assets/`.

## Notas
- Se corrigieron los nombres de archivos para evitar espacios y caracteres especiales.
- Se reorganizó la carpeta `assents` como `assets`.

